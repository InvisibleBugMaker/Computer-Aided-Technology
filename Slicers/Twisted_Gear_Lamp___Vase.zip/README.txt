                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:31722
Twisted Gear Lamp / Vase by BenitoSanduchi is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This is a precious little gear-profiled twisty vase-lamp thing!  
11/2/12 - Thanks for the all the likes and pictures of your prints.  Happy people are enjoying this design!  :)  
11/21/12 - Now available for way too much money on Shapeways.  Just in time for the holidays.  http://www.shapeways.com/model/783257/twisted-gear-vase.html?li=productBox-search  
1/26/13 - Currently available for sale at the 3DEA/Openhouse Gallery in NYC along with several of my other designs (and more awesome objects by others)! If you want one, don't have a printer, and are in New York, now's your chance. The store will be open through February 17. :D  
6/12/14 - Featured at RAPID 2014 Contemporary Art Gallery.  


# Instructions

Print with zero infill, 1-3 perimeters, and a few solid layers.  Delete the last few layers of code, stop the print before it starts bridging, or cut off the solid layers after the fact.  
*Update: With Slic3r 9.4 you can choose how many top solid layers you want.  You want 0.  
Insert LED tealight.  Ahhhh, pretty.