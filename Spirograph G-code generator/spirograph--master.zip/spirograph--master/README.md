# Spirograph
This is a spirograph generator that genorates gcode
